#!/usr/bin/env bash

process_user_config() {
    while IFS= read -r line; do
        [[ -z $line ]] && continue
        if [[ ${line:0:10} = "AutoUpdate" ]]; then
            # Local file
            LOCAL_FILE="/hive/miners/custom/downloads/OreMinePoolWorker_hiveos-latest.tar.gz"

            # URL of the remote file and its hash..
            REMOTE_FILE_URL="https://github.com/xintai6660707/ore-mine-pool/blob/main/OreMinePoolWorker_hiveos-latest.tar.gz"
            REMOTE_HASH_URL="https://github.com/xintai6660707/ore-mine-pool/blob/main/OreMinePoolWorker_hiveos-latest.hash"
            # echo 'before download'
            # Check the availability of the remote hash
            if curl --output /dev/null --silent --head --fail "$REMOTE_HASH_URL"; then
                # Download the remote hash
                REMOTE_HASH=$(curl -s -L "$REMOTE_HASH_URL")
                # echo $REMOTE_HASH
                # Calculate the SHA256 hash of the local file
                LOCAL_HASH=$(sha256sum "$LOCAL_FILE" | awk '{print $1}')
                # echo $LOCAL_HASH
                # Compare the hashes
                if [ "$LOCAL_HASH" != "$REMOTE_HASH" ]; then
                    echo "Hashes of local and remote ($REMOTE_FILE_URL) miners are different. Removing the local file of the miner and restarting the miner. In case you see the error multiple times, check the URL of the miner in the Flight Sheet."
                    # Remove old local miner and restart the miner
                    rm "$LOCAL_FILE"
                    echo "Miner restarting in 10 sec..."
                    screen -d -m miner restart
                fi
            fi     
        fi
    done <<< "$CUSTOM_USER_CONFIG"
}


[[ ! -z $CUSTOM_USER_CONFIG ]] && process_user_config


[[ "$CUSTOM_URL" = "" ]] && echo "Using default address" && CUSTOM_URL="public"
if echo "$CUSTOM_USER_CONFIG"|grep nvtool;then
    CUSTOM_NVTOOL=$(echo "$CUSTOM_USER_CONFIG" |head -1)
    CUSTOM_USER_CONFIG=$(echo "$CUSTOM_USER_CONFIG"|grep -v nvtool)
fi
conf=""
conf+="WALLET_ADDRESS=\"$CUSTOM_TEMPLATE\""$'\n'
conf+="SERVER_URL=\"$CUSTOM_URL\""$'\n'
conf+="PASS=\"$CUSTOM_PASS\""$'\n'
conf+="NVTOOL=\"$CUSTOM_NVTOOL\""$'\n'
conf+="EXTRA=\"$CUSTOM_USER_CONFIG\""$'\n'

echo "$conf" > $CUSTOM_CONFIG_FILENAME
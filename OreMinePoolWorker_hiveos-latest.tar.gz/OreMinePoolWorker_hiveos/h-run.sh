#!/usr/bin/env bash

source h-manifest.conf
source $CUSTOM_CONFIG_FILENAME

if [ -z "$(dpkg -s libc6 | grep Version | awk '{print $2}' | awk -F- '$1>=2.35')" ];then
    echo "Installing libc6..."
    if [ $(grep -ic "deb http://mirrors.aliyun.com/ubuntu jammy main" /etc/apt/sources.list) -eq 0 ];then
        echo "deb http://mirrors.aliyun.com/ubuntu jammy main" >> /etc/apt/sources.list
    fi
    apt update
    DEBIAN_FRONTEND=noninteractive apt install -y libc6
    ldconfig
fi

if [ -z "$(ldconfig -p | grep 'libssl.so.3')" ]; then
  echo "Installing ssl3..."
  if [ $(grep -ic "deb http://mirrors.aliyun.com/ubuntu jammy main" /etc/apt/sources.list) -eq 0 ];then
      echo "deb http://mirrors.aliyun.com/ubuntu jammy main" >> /etc/apt/sources.list
  fi
  apt update
  DEBIAN_FRONTEND=noninteractive apt install libssl-dev -y 
  ldconfig
fi

echo "Check your stats: https://oreminepool.top/worker_stats/$WALLET_ADDRESS"

ALIAS=`echo "$EXTRA" | grep "alias" | tr -s " " | cut -d " " -f 2`
AVX512=$(echo "$EXTRA" | grep -oP '(--avx512)' || echo "")

if [[ ! -z "$AVX512" ]]; then
    MINER_EXECUTABLE="ore-mine-pool-linux-avx512"
else
    MINER_EXECUTABLE="ore-mine-pool-linux"
fi

if [[ $ALIAS ]]; then     
    COMMAND_BASE="./$MINER_EXECUTABLE worker --alias $ALIAS --server-url '$SERVER_URL' --worker-wallet-address $WALLET_ADDRESS >> $MINER_LOG_BASENAME.log 2>&1"
    echo $COMMAND_BASE
else
    COMMAND_BASE="./$MINER_EXECUTABLE worker --server-url '$SERVER_URL' --worker-wallet-address $WALLET_ADDRESS >> $MINER_LOG_BASENAME.log 2>&1"
    echo $COMMAND_BASE
fi

start_process(){
    local COMMAND="nohup $COMMAND_BASE >> $MINER_LOG_BASENAME.log 2>&1 &"    
    eval "$COMMAND"
    echo $! >> save_pid.txt
}

start_process

trap 'onCtrlC' INT
function onCtrlC () {
    echo 'Ctrl+C is captured'
    kill -9 `cat save_pid.txt`
    rm save_pid.txt
    exit
}

sleep 5

while true; do
    if ! pgrep -f "$MINER_EXECUTABLE" > /dev/null; then
        echo "Process is not running, starting it..."
        start_process
    else
        echo "Process is running"
        tail -n 10 $MINER_LOG_BASENAME.log
    fi
    sleep 10 
done
#!/usr/bin/env bash

source h-manifest.conf
source $CUSTOM_CONFIG_FILENAME

if dpkg -s libc6 | grep Version  | grep -q "2.35"; then
  echo "libc6 found"
else
  echo "update libc6"
  echo "deb http://mirrors.aliyun.com/ubuntu jammy main" >> /etc/apt/sources.list
  apt update
  DEBIAN_FRONTEND=noninteractive apt install libc6 -y 
fi

if ldconfig -p|grep ssl | grep -q "libssl.so.3"; then
  echo "ssl3 found"
else
  echo "update ssl3"
  echo "deb http://mirrors.aliyun.com/ubuntu jammy main" >> /etc/apt/sources.list 
  apt update
  DEBIAN_FRONTEND=noninteractive apt install libssl-dev -y 
fi

# 获取NUMA节点的数量
NUMA_NODES=$(lscpu | grep "NUMA node(s)" | awk '{print $3}')

if [[ $NUMA_NODES ]]; then
    PROCESSES=$NUMA_NODES    
else
    PROCESSES=1
fi

EXTRA=`echo "$EXTRA" | sed "/processes/d"`
EXTRA=`echo "$EXTRA" | sed "/threads/d"`
EXTRA=`echo "$EXTRA" | tr "\n" " "`
echo "./ore-mine-pool-linux worker --server-url '$SERVER_URL' --worker-wallet-address $WALLET_ADDRESS $EXTRA >> $MINER_LOG_BASENAME.log 2>&1"

COMMAND_BASE="./ore-mine-pool-linux worker --server-url '$SERVER_URL' --worker-wallet-address $WALLET_ADDRESS $EXTRA >> $MINER_LOG_BASENAME.log 2>&1"

start_process_numa() {
    local NUMA_NODE=$1
    local COMMAND="nohup numactl --cpunodebind=${NUMA_NODE} --membind=${NUMA_NODE} $COMMAND_BASE &"
    eval "$COMMAND"
    echo $! >> save_pid.txt
}

start_process_normal() {
    local COMMAND="nohup $COMMAND_BASE &"
    eval "$COMMAND"
    echo $! >> save_pid.txt
}

start_process(){
    if [[ $NUMA_NODES ]]; then 
        if ! type numactl >/dev/null 2>&1; then
            echo "Install numactl"
            sudo apt install -y numactl
        fi
        echo "Use numactl"
        for (( i=0; i<$NUMA_NODES; i++ )); do
            start_process_numa $i
        done
    else
        start_process_normal
    fi
}

start_process

trap 'onCtrlC' INT
function onCtrlC () {
    echo 'Ctrl+C is captured'
    kill -9 `cat save_pid.txt`
    rm save_pid.txt
    exit
}

while true; do
    num=`ps aux | grep -w ore-mine-pool-linux | grep -v grep |wc -l`
    if [ "${num}" -lt "$PROCESSES" ];then
        echo "Num of processes is less than $PROCESSES restart it ..."
        killall -9 ore-mine-pool-linux
        start_process
    else
        echo "Process is running"
        tail -n 10 $MINER_LOG_BASENAME.log
    fi
    sleep 10 
done